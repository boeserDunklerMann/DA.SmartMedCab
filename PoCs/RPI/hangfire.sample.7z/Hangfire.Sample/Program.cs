﻿namespace Hangfire.Sample
{
	internal class Program
	{
		static void Main(string[] args)
		{
			GlobalConfiguration.Configuration
				.SetDataCompatibilityLevel(CompatibilityLevel.Version_180)
				.UseColouredConsoleLogProvider()
				.UseSimpleAssemblyNameTypeSerializer()
				.UseRecommendedSerializerSettings()
				.UseSqlServerStorage("Server=.\\SQLExpress; Database=Hangfire.Sample; Integrated Security=False; Encrypt=False;user=HangFire;Password=hangfire.0815");

			IProcess process = new Forecast();
			if (process != null)
			{
				BackgroundJob.Enqueue(() => process.RunAsync());
			}
			//using (var server=new BackgroundJobServer())
			//{
			//	Console.ReadKey();
			//}
		}
	}
}
