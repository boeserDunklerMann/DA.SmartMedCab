﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hangfire.Sample
{
	public class Test : IProcess
	{
		public async Task RunAsync()
		{
            await Console.Out.WriteLineAsync($"Hello world from {nameof(Test)}");
        }
	}
}
