﻿namespace Hangfire.Sample
{
	public interface IProcess
	{
		Task RunAsync();
	}
}