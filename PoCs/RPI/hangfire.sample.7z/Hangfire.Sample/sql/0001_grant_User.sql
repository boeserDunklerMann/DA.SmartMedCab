use [Hangfire.Sample]
GO
GRANT CREATE schema TO [Hangfire]
GRANT CREATE table TO [Hangfire]
GO
