create login HangFire
with password = 'hangfire.0815';
go

create user Hangfire for login HangFire;
go
