using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Hangfire.Sample.WebApp.Pages
{
	public class IndexModel : PageModel
	{
		private readonly ILogger<IndexModel> _logger;

		public IndexModel(ILogger<IndexModel> logger, IBackgroundJobClient backgroundJobs, Microsoft.Extensions.Hosting.IHostEnvironment env)
		{
			_logger = logger;
			IProcess process = new Forecast();
			backgroundJobs.Enqueue(() => process.RunAsync());
		}

		public void OnGet()
		{

		}
	}
}
